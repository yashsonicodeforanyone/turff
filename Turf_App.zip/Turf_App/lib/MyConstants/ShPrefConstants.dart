const sp_admin = "Sp_admin";
const sp_login = "Sp_login";
const sp_name = "sp_name";
const sp_profile_image = "sp_profile_image";
const sp_contact = "sp_contact";
const sp_gender = "sp_gender";
const sp_userId = "sp_userId";
const sp_usertype = "sp_usertype";
const sp_address = "sp_address";

const sp_hotelName = "sp_hotelName";
const sp_hotelImg = "sp_hotelImg";
const sp_roomNo = "sp_roomNo";
const sp_availableRoom = "sp_availaibleRoom";
const sp_supName = " sp_supName";
const sp_supEmail  = "sp_supEmail";
const sp_supNumber = "sp_supNumber";
const sp_supType = "sp_supType";
const sp_supMsg = "sp_supMsg";

const sp_turfId = "savedIDs";