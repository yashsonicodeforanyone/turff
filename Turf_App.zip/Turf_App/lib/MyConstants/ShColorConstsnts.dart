import 'package:flutter/material.dart';
const sh_appColor = Color(0xffEE7B23);
const sh_gray = Color(0xff3d3d3d);
